The following is the directory for the code files for this project.  They were coded and run in MATALAB 2017B.

Original Model: GolfSportCodeOriginal.m
Modified for Practicality: ModifiedPracticalGolfSportCode.m
Doubling Demand: GolfSportCodeIncreaseDemand.m
Increasing Advertising Budget/Increasing Graphite: GolfSportCodeIncreasedAdvBudget.m and GolfSportCodeGraphiteIncrease.m